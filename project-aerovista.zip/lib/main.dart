import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() => runApp(const AeroVistaApp());

class AeroVistaApp extends StatelessWidget {
  const AeroVistaApp({super.key});
  @override
  Widget build(BuildContext context) => const MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AeroVista',
    home: AeroVistaHome(),
  );
}

class AeroVistaHome extends StatefulWidget {
  const AeroVistaHome({super.key});
  @override
  State<AeroVistaHome> createState() => _AeroVistaHomeState();
}

class _AeroVistaHomeState extends State<AeroVistaHome> {
  late final WebViewController controller;
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF080B14))
      ..setNavigationDelegate(NavigationDelegate())
      ..loadFlutterAsset('assets/index.html');
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF080B14),
    body: SafeArea(child: WebViewWidget(controller: controller)),
  );
}
